// Copyright (c) 2014 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

document.addEventListener('DOMContentLoaded', function() {
  script = "if (window.location.href.startsWith('https://lex.infosysapps.com/en/viewer/web-module/lex_auth_'))"+
			"document.getElementsByClassName('web-module-iframe ng-star-inserted')[0].style.height='80vh';"+
			"else alert('Not correct website');";
  chrome.tabs.executeScript(null, {code:script}, function(results){ /*alert(results);*/ });
});