function pageChangeFunction(event){
	if (event.key=='ArrowLeft'){
		document.getElementsByClassName('mat-icon notranslate whiteIcon material-icons mat-icon-no-color')[0].click();
	}
	else if (event.key=='ArrowRight'){
		document.getElementsByClassName('mat-icon notranslate whiteIcon material-icons mat-icon-no-color')[1].click();
	}
}

function taskFunction(){
	frames = document.getElementsByClassName('web-module-iframe ng-star-inserted');
		if(frames.length > 0){
			if (window.location.href.startsWith('https://lex.infosysapps.com/en/viewer/web-module/lex_auth_')){
				frames[0].style.height='80vh';
			}
			frames[0].focus();
			frames[0].contentWindow.document.getElementsByClassName('app-background indigo custom-scroll-small')[0].addEventListener('keyup',pageChangeFunction);
		}
}

setTimeout(taskFunction, 5000);