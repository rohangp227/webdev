set access to specific sites :
https://lex.infosysapps.com/*