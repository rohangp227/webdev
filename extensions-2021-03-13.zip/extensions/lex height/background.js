//gives error when new tab(chrome://newtab) opens or any chrome:// page opens
chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete' && tab.active) {
    //script = "alert('ok')";
    //chrome.tabs.executeScript(null, {code:script}, function(results){ /*alert(results);*/ });
    
	chrome.tabs.executeScript(null, {file:"task.js"}, function(results){});
  }
});