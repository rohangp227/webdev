import java.awt.*;
import java.applet.*;
public class MyApplet extends Applet{
public void paint(Graphics g){
g.drawString("Hello world",50,50);
}
}