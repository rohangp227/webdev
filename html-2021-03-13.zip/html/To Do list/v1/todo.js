var newtask= document.getElementById("newtask");
newtask.focus();
newtask.select();
var addtask= document.getElementById("addtask");
var list= document.getElementById("list");
newtask.addEventListener("keypress", function(event){
	//event.preventDefault();
	if(event.keyCode==13){
		addtask.click();
	}
});
function addTask(){
	if(newtask.value.trim()!=""){
	var item= document.createElement("div");
	item.className= "item";
	item.onclick="taskDone()";
	var checkbox= document.createElement("img");
	checkbox.className= "checkbox";
	var node= document.createTextNode(" "+newtask.value.trim());
	//node.padding= "10px";
	item.appendChild(checkbox);
	item.appendChild(node);
	list.appendChild(item);
	document.getElementById("sidebar").classList.toggle("slide");
	newtask.value="";
	}
}
function taskDone(){
	alert("1");
}