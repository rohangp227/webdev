var newtask= document.getElementById("newtask");
newtask.focus();
newtask.select();
var addtask= document.getElementById("addtask");
var list= document.getElementById("list");
newtask.addEventListener("keypress", function(event){
	//event.preventDefault();
	if(event.keyCode==13){
		addtask.click();
	}
});
function addTask(){
	var tasktext= newtask.value.trim();
	if(tasktext.length>70){
		alert("Enter smaller title in task");
	}
	else{
	if(newtask.value.trim()!=""){
	var item= document.createElement("div");
	item.className= "item";
	var complete= "line-through";
	var incomplete= "none";
	item.style.textDecoration=  incomplete;
	var checkbox= document.createElement("img");
	checkbox.className= "checkbox";
	checkbox.src="uncheck.png";
	item.appendChild(checkbox);
	tasktext= newtask.value.trim();
	/*if(tasktext.length>70){
		tasktext= tasktext.substr(0,70);
		var node= document.createTextNode(" "+tasktext);
		item.appendChild(node);
		tasktext= tasktext.substr(70,tasktext.length);
		var para= document.createElement("p");
		node= document.createTextNode(" "+tasktext);
		para.appendChild(node);
		item.appendChild(para);
	}
	else{*/
		var node= document.createTextNode(" "+tasktext);
		item.appendChild(node);
	//}
	var close= document.createElement("img");
	close.className= "close";
	close.src="close.png";
	close.align="right";
	close.addEventListener("click", function(){
		this.parentElement.style.display="none";
	});
	item.appendChild(close);
	list.appendChild(item);
	checkbox.addEventListener("click", function(){
		var c= this;
		var t= this.parentElement;
		if(t.style.textDecoration==incomplete){
			c.src="check anim.gif";
			setTimeout(function(){c.src="check.gif";},2000);
			t.style.textDecoration= complete;
		}
		else{
			c.src="uncheck.png";
			t.style.textDecoration= incomplete;
		}
	});
	newtask.value="";
	}
	}
}
function slide(){
	var sidebar= document.getElementById("sidebar");
	var main= document.getElementById("main");
	document.getElementById("bar1").classList.toggle("change");
	document.getElementById("bar2").classList.toggle("change");
	document.getElementById("bar3").classList.toggle("change");
	sidebar.classList.toggle("slide");
	main.classList.toggle("slide");
}