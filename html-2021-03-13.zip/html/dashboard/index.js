var data= {"A":50,"B":50};
var total=0;
var keys=[];
var values=[];
for(key in data){
	keys.push(key);
	temp=data[key];
	values.push(temp);
	total+=temp;
}

function pieChartDisplay(){
	
}
var temp_per=5;
var fill="white"
if(temp_per>50){
	temp_per=temp_per-50;
	fill="black";
}
var angle= -90+temp_per*360/100;
var pieCharts = document.getElementsByClassName("pie-chart");
/*for(i=0;i<pieCharts.length;i++){
	pieCharts[i].style.backgroundImage="linear-gradient(-90deg, black 50%, transparent 50%),linear-gradient(0deg, transparent 50%, black 50%)";
}*/
document.getElementsByClassName("pie-chart")[0].style.backgroundImage="linear-gradient("+angle+"deg, "+fill+" 50%, transparent 50%), linear-gradient(90deg, transparent 50%, black 50%)";